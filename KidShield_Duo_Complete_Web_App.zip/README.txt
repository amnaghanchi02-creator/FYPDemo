# KidShield Duo — Responsive FYP Web App

This is a responsive, installable PWA starter based on your uploaded KidShield Duo dashboard.

## Run on your computer
1. Extract the ZIP.
2. Open the `public` folder.
3. For a quick visual preview, double-click `index.html`.
4. For PWA/offline support, run a local web server from the `public` folder:
   - Install Python 3 if needed.
   - Open Command Prompt in the `public` folder.
   - Run: `python -m http.server 8000`
   - Open: `http://localhost:8000`

## Put it online so phones and PCs can open it
Upload the contents of the `public` folder to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages. Use the HTTPS website URL on phones and computers. PWA installation requires HTTPS (or localhost).

## Important current limitations
- This version is a polished front-end demo. It saves profile, settings, checklist and event history in the current browser using localStorage.
- Data is NOT synchronized between different phones/computers yet. Each browser has its own local data.
- The map pin and sample sensor readings are demonstration data, not the child's live GPS or real sensor values.
- The browser geolocation button reads the device that opened the website, not a separate child wearable.
- SOS is a demo event only. It does not send SMS, place calls, contact emergency services or notify a physical watch.
- Real cross-device accounts, shared database, GPS updates, MQTT/device communication, push notifications and real SOS delivery need a secure hosted backend and device firmware. Do not use this demo as a real emergency service.

## FYP project information retained
- Project: KidShield Duo
- Team: Amna Ashraf and Zulfqar Ali
- Supervisor: Sir Faizan Ur Rehman
